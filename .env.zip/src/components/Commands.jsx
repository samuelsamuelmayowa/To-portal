import { useEffect, useMemo, useState } from "react";
import { Search, ChevronDown, ChevronUp, Copy } from "lucide-react";
import { toast } from "sonner";

/* ================================
   ✅ YOUR FULL COMMANDS (UNCHANGED)
================================== */
const COMMANDS = [
  // ================= SEARCH COMMANDS =================
  {
    name: "chart / timechart",
    description: "Tabular / time-series chart output",
    category: "Search Commands",
  },
  {
    name: "dedup",
    description: "Remove duplicate events",
    category: "Search Commands",
  },
  {
    name: "eval",
    description: "Create or modify fields",
    category: "Search Commands",
  },
  {
    name: "fields",
    description: "Include or exclude fields",
    category: "Search Commands",
  },
  {
    name: "head / tail",
    description: "First or last N results",
    category: "Search Commands",
  },
  {
    name: "lookup",
    description: "Add fields from lookup tables",
    category: "Search Commands",
  },
  { name: "rename", description: "Rename fields", category: "Search Commands" },
  {
    name: "rex",
    description: "Extract fields using regex",
    category: "Search Commands",
  },
  { name: "search", description: "Filter events", category: "Search Commands" },
  { name: "sort", description: "Sort results", category: "Search Commands" },
  {
    name: "stats",
    description: "Aggregate statistics",
    category: "Search Commands",
  },
  {
    name: "mstats",
    description: "Metrics version of stats",
    category: "Search Commands",
  },
  {
    name: "table",
    description: "Show only specific fields",
    category: "Search Commands",
  },
  {
    name: "top / rare",
    description: "Most / least common values",
    category: "Search Commands",
  },
  {
    name: "transaction",
    description: "Group events",
    category: "Search Commands",
  },
  {
    name: "where",
    description: "Eval-based filtering",
    category: "Search Commands",
  },

  // ================= EVAL FUNCTIONS =================
  { name: "abs(X)", description: "Absolute value", category: "Eval Functions" },
  {
    name: "case()",
    description: "Conditional branching",
    category: "Eval Functions",
  },
  {
    name: "ceil(X)",
    description: "Ceiling integer",
    category: "Eval Functions",
  },
  {
    name: "cidrmatch()",
    description: "Match IP in CIDR",
    category: "Eval Functions",
  },
  {
    name: "coalesce()",
    description: "First non-null",
    category: "Eval Functions",
  },
  { name: "cos(X)", description: "Cosine", category: "Eval Functions" },
  { name: "exp(X)", description: "e^X", category: "Eval Functions" },
  {
    name: "if(X,Y,Z)",
    description: "Conditional logic",
    category: "Eval Functions",
  },
  {
    name: "in()",
    description: "Check value in list",
    category: "Eval Functions",
  },
  {
    name: "isbool / isint / isnull",
    description: "Type checks",
    category: "Eval Functions",
  },
  { name: "len(X)", description: "String length", category: "Eval Functions" },
  {
    name: "like(X,Y)",
    description: "Wildcard match",
    category: "Eval Functions",
  },
  { name: "log(X,Y)", description: "Logarithm", category: "Eval Functions" },
  { name: "lower(X)", description: "Lowercase", category: "Eval Functions" },
  {
    name: "ltrim / rtrim",
    description: "Trim characters",
    category: "Eval Functions",
  },
  { name: "match()", description: "Regex match", category: "Eval Functions" },
  {
    name: "max(X,...)",
    description: "Returns maximum",
    category: "Eval Functions",
  },
  {
    name: "md5(X)",
    description: "Returns MD5 hash",
    category: "Eval Functions",
  },
  {
    name: "min(X,...)",
    description: "Returns minimum",
    category: "Eval Functions",
  },
  {
    name: "mvcount(X)",
    description: "Number of values",
    category: "Eval Functions",
  },
  {
    name: "mvfilter(X)",
    description: "Filters multivalued field",
    category: "Eval Functions",
  },
  {
    name: "mvindex(X,Y,Z)",
    description: "Subset of multivalued field",
    category: "Eval Functions",
  },
  {
    name: "mvjoin(X,Y)",
    description: "Join multivalued field",
    category: "Eval Functions",
  },
  {
    name: "now()",
    description: "Current Unix time",
    category: "Eval Functions",
  },
  { name: "null()", description: "Returns NULL", category: "Eval Functions" },
  {
    name: "nullif(X,Y)",
    description: "Returns X if different from Y",
    category: "Eval Functions",
  },
  {
    name: "random()",
    description: "Random number generator",
    category: "Eval Functions",
  },
  {
    name: "relative_time(X,Y)",
    description: "Apply relative time to epoch",
    category: "Eval Functions",
  },
  {
    name: "round(X,Y)",
    description: "Round number",
    category: "Eval Functions",
  },
  {
    name: "split(X,Y)",
    description: "Split string into multivalue",
    category: "Eval Functions",
  },
  { name: "sqrt(X)", description: "Square root", category: "Eval Functions" },
  {
    name: "strftime(X,Y)",
    description: "Epoch to formatted string",
    category: "Eval Functions",
  },
  {
    name: "strptime(X,Y)",
    description: "Parse string to epoch",
    category: "Eval Functions",
  },
  {
    name: "substr(X,Y,Z)",
    description: "Substring from position",
    category: "Eval Functions",
  },
  {
    name: "time()",
    description: "Wall clock time",
    category: "Eval Functions",
  },
  {
    name: "tonumber(X,Y)",
    description: "String to number",
    category: "Eval Functions",
  },
  {
    name: "tostring(X,Y)",
    description: "Convert to string",
    category: "Eval Functions",
  },
  {
    name: "typeof(X)",
    description: "Returns field type",
    category: "Eval Functions",
  },
  {
    name: "urldecode(X)",
    description: "Decode URL",
    category: "Eval Functions",
  },
  {
    name: "validate(X,Y,...)",
    description: "Validation logic",
    category: "Eval Functions",
  },

  // ================= STATS FUNCTIONS =================
  { name: "avg(X)", description: "Average", category: "Stats Functions" },
  {
    name: "count(X)",
    description: "Count events",
    category: "Stats Functions",
  },
  { name: "dc(X)", description: "Distinct count", category: "Stats Functions" },
  {
    name: "earliest(X)",
    description: "Earliest value/time",
    category: "Stats Functions",
  },
  {
    name: "latest(X)",
    description: "Latest value/time",
    category: "Stats Functions",
  },
  {
    name: "median(X)",
    description: "Median value",
    category: "Stats Functions",
  },
  { name: "percX(Y)", description: "Percentile", category: "Stats Functions" },
  { name: "range(X)", description: "Max - Min", category: "Stats Functions" },
  {
    name: "stdev / stdevp",
    description: "Standard deviation",
    category: "Stats Functions",
  },
  { name: "sum(X)", description: "Sum of values", category: "Stats Functions" },
  {
    name: "values(X)",
    description: "Distinct list",
    category: "Stats Functions",
  },

  // ================= REGEX =================
  { name: "\\s", description: "Whitespace", category: "Regex Reference" },
  { name: "\\S", description: "Non-whitespace", category: "Regex Reference" },
  { name: "\\d", description: "Digit", category: "Regex Reference" },
  { name: "\\D", description: "Non-digit", category: "Regex Reference" },
  { name: "\\w", description: "Word character", category: "Regex Reference" },
  {
    name: "\\W",
    description: "Non-word character",
    category: "Regex Reference",
  },
  { name: "*", description: "Zero or more", category: "Regex Reference" },
  { name: "+", description: "One or more", category: "Regex Reference" },
  { name: "?", description: "Optional", category: "Regex Reference" },
  { name: "^", description: "Start of line", category: "Regex Reference" },
  { name: "$", description: "End of line", category: "Regex Reference" },

  // ================= TIME FORMATS =================
  { name: "%H", description: "Hour (00–23)", category: "Date & Time Formats" },
  { name: "%M", description: "Minute", category: "Date & Time Formats" },
  { name: "%S", description: "Seconds", category: "Date & Time Formats" },
  { name: "%Y", description: "Year full", category: "Date & Time Formats" },
  { name: "%y", description: "Year short", category: "Date & Time Formats" },
  { name: "%m", description: "Month", category: "Date & Time Formats" },
  { name: "%d", description: "Day of month", category: "Date & Time Formats" },
  { name: "%p", description: "AM / PM", category: "Date & Time Formats" },
  {
    name: "%z",
    description: "Timezone offset",
    category: "Date & Time Formats",
  },
  { name: "%Z", description: "Timezone name", category: "Date & Time Formats" },
  {
    name: "%s",
    description: "Seconds since 1970",
    category: "Date & Time Formats",
  },
];

/* ================================
   CARD (Expandable + Copy Example)
================================== */
function CommandCard({ cmd }) {
  const [open, setOpen] = useState(false);

  // Simple SPL example generator (students can copy/paste)
  const splExample = useMemo(() => {
    const n = cmd.name;

    // give smarter examples for common items
    if (n.includes("stats")) return "index=_internal | stats count by sourcetype";
    if (n.includes("timechart")) return "index=_internal | timechart span=1h count";
    if (n === "rex") return 'index=_internal | rex field=_raw "error=(?<err>\\w+)"';
    if (n === "eval") return 'index=_internal | eval severity=if(like(_raw,"%ERROR%"),"high","low")';
    if (n.startsWith("%")) return `| eval t=strftime(now(),"${n}")`;
    if (n.startsWith("\\")) return `| rex field=_raw "(?<match>${n}+)"`;

    return `index=_internal | ${cmd.name}`;
  }, [cmd.name]);

  return (
    <div className="bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-xl p-5 shadow hover:shadow-md transition">
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        className="w-full text-left flex items-start justify-between gap-4"
      >
        <div className="min-w-0">
          <h3 className="text-gray-900 dark:text-white text-lg font-semibold break-words">
            {cmd.name}
          </h3>
          <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
            {cmd.description}
          </p>
          <p className="text-xs text-gray-500 dark:text-gray-500 mt-2">
            {cmd.category}
          </p>
        </div>

        <div className="pt-1 shrink-0 text-gray-600 dark:text-gray-300">
          {open ? <ChevronUp size={18} /> : <ChevronDown size={18} />}
        </div>
      </button>

      {open && (
        <div className="mt-4">
          <div className="relative bg-gray-100 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg p-3 font-mono text-sm overflow-x-auto">
            {splExample}

            <button
              type="button"
              onClick={() => {
                navigator.clipboard.writeText(splExample);
                toast.success("SPL example copied");
              }}
              className="absolute top-2 right-2 inline-flex items-center gap-1 text-xs px-2 py-1 rounded-md
                         bg-white/80 dark:bg-gray-900/60 border border-gray-300 dark:border-gray-700
                         hover:bg-white dark:hover:bg-gray-900 transition"
            >
              <Copy size={14} />
              Copy
            </button>
          </div>

          <p className="mt-3 text-sm text-gray-600 dark:text-gray-400">
            ✅ Tip: Copy the SPL into Splunk Search and tweak it to match your index/sourcetype.
          </p>
        </div>
      )}
    </div>
  );
}

/* ================================
   MAIN PAGE
================================== */
export default function Commands() {
  const [search, setSearch] = useState("");
  const [darkMode, setDarkMode] = useState(false);
  const [userEmail, setUserEmail] = useState("");

  // ✅ Fix: run once
  useEffect(() => {
    setUserEmail(localStorage.getItem("user") || "");
  }, []);

  // ✅ Make darkMode actually apply to the app
  useEffect(() => {
    const root = document.documentElement; // <html>
    if (darkMode) root.classList.add("dark");
    else root.classList.remove("dark");
  }, [darkMode]);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) return COMMANDS;

    return COMMANDS.filter(
      (cmd) =>
        cmd.name.toLowerCase().includes(q) ||
        cmd.description.toLowerCase().includes(q) ||
        cmd.category.toLowerCase().includes(q)
    );
  }, [search]);

  // ✅ Group by category
  const grouped = useMemo(() => {
    return filtered.reduce((acc, cmd) => {
      const key = cmd.category || "Other";
      acc[key] = acc[key] || [];
      acc[key].push(cmd);
      return acc;
    }, {});
  }, [filtered]);

  return (
    <div className="min-h-screen bg-white dark:bg-gray-950 text-gray-900 dark:text-gray-100 p-6 mt-1">
      {/* HEADER */}
      {/* <div className="max-w-7xl mx-auto mb-6">
        <div className="dashboard-topbar bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-2xl p-6 shadow flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-800 dark:text-white">
              To-Analytics Learning Portal
            </h1>
            <p className="text-sm text-gray-500 dark:text-gray-400">
              Professional Splunk Bootcamp Dashboard
            </p>
          </div>

          <div className="flex items-center gap-4">
            <div className="text-sm text-gray-600 dark:text-gray-300">
              {userEmail}
            </div>


            <button
              type="button"
              onClick={() => setDarkMode((v) => !v)}
              className="px-3 py-1 rounded-lg text-sm
              bg-gray-100 text-gray-800
              dark:bg-gray-800 dark:text-white
              border border-gray-300 dark:border-gray-700
              hover:bg-gray-200 dark:hover:bg-gray-700 transition"
            >
              {darkMode ? "Light Mode" : "Dark Mode"}
            </button>
          </div>
        </div>
      </div> */}

      {/* TITLE */}
      <div className="max-w-7xl mx-auto">
        <h1 className="text-3xl font-bold mb-2 text-gray-800 dark:text-white">
          Splunk Command Explorer
        </h1>
        <p className="text-sm text-gray-500 dark:text-gray-400 mb-6">
          Search, expand, and copy SPL examples to practice faster.
        </p>

        {/* SEARCH BAR */}
        <div className="flex items-center bg-white dark:bg-gray-900 border border-gray-300 dark:border-gray-700 rounded-xl p-3 mb-8 max-w-md shadow">
          <Search className="text-gray-500 mr-2" size={18} />
          <input
            type="text"
            placeholder="Search command, regex, function..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="bg-transparent w-full outline-none text-gray-800 dark:text-white placeholder:text-gray-400"
          />
        </div>

        {/* RESULTS (Grouped Sections) */}
        <div className="space-y-10">
          {Object.entries(grouped).map(([category, items]) => (
            <section key={category}>
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl font-bold text-gray-800 dark:text-white">
                  {category}
                </h2>
                <span className="text-xs text-gray-500 dark:text-gray-400">
                  {items.length} items
                </span>
              </div>

              <div className="grid md:grid-cols-2 gap-6">
                {items.map((cmd, index) => (
                  <CommandCard key={`${cmd.name}-${index}`} cmd={cmd} />
                ))}
              </div>
            </section>
          ))}
        </div>

        {/* DOCUMENT SECTION */}
        <div className="mt-10">{/* Keep for future document preview */}</div>
      </div>
    </div>
  );
}

// import { useState, useEffect } from "react";
// import { Search, ChevronDown, ChevronUp, Copy } from "lucide-react";
// import DashboardDropdown from "./Dropdown";
// import { toast } from "sonner";

// /* ================= COMMAND DATA ================= */

// const COMMANDS = [
//   { name: "stats", description: "Aggregate statistics", category: "Search Commands", level: "Beginner" },
//   { name: "timechart", description: "Time-series aggregation", category: "Search Commands", level: "Beginner" },
//   { name: "eval", description: "Create or modify fields", category: "Search Commands", level: "Beginner" },
//   { name: "rex", description: "Extract fields using regex", category: "Search Commands", level: "Intermediate" },
//   { name: "transaction", description: "Group related events", category: "Search Commands", level: "Advanced" },

//   { name: "if(X,Y,Z)", description: "Conditional logic", category: "Eval Functions", level: "Beginner" },
//   { name: "case()", description: "Multiple conditions", category: "Eval Functions", level: "Intermediate" },
//   { name: "strftime()", description: "Epoch → formatted time", category: "Eval Functions", level: "Beginner" },

//   { name: "count(X)", description: "Count events", category: "Stats Functions", level: "Beginner" },
//   { name: "avg(X)", description: "Average value", category: "Stats Functions", level: "Beginner" },
//   { name: "dc(X)", description: "Distinct count", category: "Stats Functions", level: "Intermediate" },

//   { name: "\\d", description: "Digit matcher", category: "Regex Reference", level: "Beginner" },
//   { name: "\\w", description: "Word character", category: "Regex Reference", level: "Beginner" },

//   { name: "%Y", description: "4-digit year", category: "Date & Time Formats", level: "Beginner" },
//   { name: "%m", description: "Month", category: "Date & Time Formats", level: "Beginner" },
// ];

// /* ================= COMMAND CARD ================= */

// function CommandCard({ cmd }) {
//   const [open, setOpen] = useState(false);

//   const example = `index=_internal | ${cmd.name}`;

//   return (
//     <div className="bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-xl p-5 shadow">
//       <div
//         className="flex items-center justify-between cursor-pointer"
//         onClick={() => setOpen(!open)}
//       >
//         <div>
//           <h3 className="text-lg font-semibold">{cmd.name}</h3>
//           <p className="text-sm text-gray-500">{cmd.description}</p>

//           <span
//             className={`inline-block mt-2 text-xs px-2 py-1 rounded
//               ${cmd.level === "Beginner" && "bg-green-100 text-green-700"}
//               ${cmd.level === "Intermediate" && "bg-yellow-100 text-yellow-700"}
//               ${cmd.level === "Advanced" && "bg-red-100 text-red-700"}
//             `}
//           >
//             {cmd.level}
//           </span>
//         </div>

//         {open ? <ChevronUp /> : <ChevronDown />}
//       </div>

//       {open && (
//         <div className="mt-4 space-y-3">
//           <div className="bg-gray-100 dark:bg-gray-800 p-3 rounded-lg font-mono text-sm relative">
//             {example}
//             <button
//               onClick={() => {
//                 navigator.clipboard.writeText(example);
//                 toast.success("SPL copied");
//               }}
//               className="absolute top-2 right-2 text-xs flex gap-1 text-blue-600"
//             >
//               <Copy size={14} /> Copy
//             </button>
//           </div>

//           <p className="text-sm text-gray-600 dark:text-gray-400">
//             💡 Used frequently in real-world Splunk searches and dashboards.
//           </p>
//         </div>
//       )}
//     </div>
//   );
// }

// /* ================= MAIN PAGE ================= */

// export default function Commands() {
//   const [search, setSearch] = useState("");
//   const [userEmail, setUserEmail] = useState("");

//   useEffect(() => {
//     setUserEmail(localStorage.getItem("user") || "");
//   }, []);

//   const filtered = COMMANDS.filter(
//     (cmd) =>
//       cmd.name.toLowerCase().includes(search.toLowerCase()) ||
//       cmd.description.toLowerCase().includes(search.toLowerCase()) ||
//       cmd.category.toLowerCase().includes(search.toLowerCase())
//   );

//   const grouped = filtered.reduce((acc, cmd) => {
//     acc[cmd.category] = acc[cmd.category] || [];
//     acc[cmd.category].push(cmd);
//     return acc;
//   }, {});

//   return (
//     <div className="min-h-screen bg-gray-50 dark:bg-gray-950 text-gray-900 dark:text-gray-100 p-6">
//       {/* HEADER */}
//       <div className="max-w-7xl mx-auto mb-8">
//         <div className="bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-2xl p-6 shadow flex justify-between">
//           <div>
//             <h1 className="text-2xl font-bold">To-Analytics Learning Portal</h1>
//             <p className="text-sm text-gray-500">Splunk Command Explorer</p>
//           </div>

//           <div className="flex items-center gap-4">
//             <span className="text-sm text-gray-500">{userEmail}</span>
//             <DashboardDropdown />
//           </div>
//         </div>
//       </div>

//       {/* SEARCH */}
//       <div className="flex items-center bg-white dark:bg-gray-900 border border-gray-300 dark:border-gray-700 rounded-xl p-3 mb-8 max-w-md shadow">
//         <Search className="mr-2 text-gray-500" size={18} />
//         <input
//           type="text"
//           placeholder="Search SPL command, function, regex..."
//           value={search}
//           onChange={(e) => setSearch(e.target.value)}
//           className="w-full bg-transparent outline-none"
//         />
//       </div>

//       {/* RESULTS */}
//       <div className="space-y-10">
//         {Object.entries(grouped).map(([category, items]) => (
//           <div key={category}>
//             <h2 className="text-xl font-bold mb-4">{category}</h2>

//             <div className="grid md:grid-cols-2 gap-6">
//               {items.map((cmd, i) => (
//                 <CommandCard key={i} cmd={cmd} />
//               ))}
//             </div>
//           </div>
//         ))}
//       </div>
//     </div>
//   );
// }


// // import { useState } from "react";
// // import { Search } from "lucide-react";
// // import DashboardDropdown from "./Dropdown";
// // import { useEffect } from "react";
// // const COMMANDS = [
// //   // ================= SEARCH COMMANDS =================
// //   {
// //     name: "chart / timechart",
// //     description: "Tabular / time-series chart output",
// //     category: "Search Commands",
// //   },
// //   {
// //     name: "dedup",
// //     description: "Remove duplicate events",
// //     category: "Search Commands",
// //   },
// //   {
// //     name: "eval",
// //     description: "Create or modify fields",
// //     category: "Search Commands",
// //   },
// //   {
// //     name: "fields",
// //     description: "Include or exclude fields",
// //     category: "Search Commands",
// //   },
// //   {
// //     name: "head / tail",
// //     description: "First or last N results",
// //     category: "Search Commands",
// //   },
// //   {
// //     name: "lookup",
// //     description: "Add fields from lookup tables",
// //     category: "Search Commands",
// //   },
// //   { name: "rename", description: "Rename fields", category: "Search Commands" },
// //   {
// //     name: "rex",
// //     description: "Extract fields using regex",
// //     category: "Search Commands",
// //   },
// //   { name: "search", description: "Filter events", category: "Search Commands" },
// //   { name: "sort", description: "Sort results", category: "Search Commands" },
// //   {
// //     name: "stats",
// //     description: "Aggregate statistics",
// //     category: "Search Commands",
// //   },
// //   {
// //     name: "mstats",
// //     description: "Metrics version of stats",
// //     category: "Search Commands",
// //   },
// //   {
// //     name: "table",
// //     description: "Show only specific fields",
// //     category: "Search Commands",
// //   },
// //   {
// //     name: "top / rare",
// //     description: "Most / least common values",
// //     category: "Search Commands",
// //   },
// //   {
// //     name: "transaction",
// //     description: "Group events",
// //     category: "Search Commands",
// //   },
// //   {
// //     name: "where",
// //     description: "Eval-based filtering",
// //     category: "Search Commands",
// //   },

// //   // ================= EVAL FUNCTIONS =================
// //   { name: "abs(X)", description: "Absolute value", category: "Eval Functions" },
// //   {
// //     name: "case()",
// //     description: "Conditional branching",
// //     category: "Eval Functions",
// //   },
// //   {
// //     name: "ceil(X)",
// //     description: "Ceiling integer",
// //     category: "Eval Functions",
// //   },
// //   {
// //     name: "cidrmatch()",
// //     description: "Match IP in CIDR",
// //     category: "Eval Functions",
// //   },
// //   {
// //     name: "coalesce()",
// //     description: "First non-null",
// //     category: "Eval Functions",
// //   },
// //   { name: "cos(X)", description: "Cosine", category: "Eval Functions" },
// //   { name: "exp(X)", description: "e^X", category: "Eval Functions" },
// //   {
// //     name: "if(X,Y,Z)",
// //     description: "Conditional logic",
// //     category: "Eval Functions",
// //   },
// //   {
// //     name: "in()",
// //     description: "Check value in list",
// //     category: "Eval Functions",
// //   },
// //   {
// //     name: "isbool / isint / isnull",
// //     description: "Type checks",
// //     category: "Eval Functions",
// //   },
// //   { name: "len(X)", description: "String length", category: "Eval Functions" },
// //   {
// //     name: "like(X,Y)",
// //     description: "Wildcard match",
// //     category: "Eval Functions",
// //   },
// //   { name: "log(X,Y)", description: "Logarithm", category: "Eval Functions" },
// //   { name: "lower(X)", description: "Lowercase", category: "Eval Functions" },
// //   {
// //     name: "ltrim / rtrim",
// //     description: "Trim characters",
// //     category: "Eval Functions",
// //   },
// //   { name: "match()", description: "Regex match", category: "Eval Functions" },
// //   {
// //     name: "max(X,...)",
// //     description: "Returns maximum",
// //     category: "Eval Functions",
// //   },
// //   {
// //     name: "md5(X)",
// //     description: "Returns MD5 hash",
// //     category: "Eval Functions",
// //   },
// //   {
// //     name: "min(X,...)",
// //     description: "Returns minimum",
// //     category: "Eval Functions",
// //   },
// //   {
// //     name: "mvcount(X)",
// //     description: "Number of values",
// //     category: "Eval Functions",
// //   },
// //   {
// //     name: "mvfilter(X)",
// //     description: "Filters multivalued field",
// //     category: "Eval Functions",
// //   },
// //   {
// //     name: "mvindex(X,Y,Z)",
// //     description: "Subset of multivalued field",
// //     category: "Eval Functions",
// //   },
// //   {
// //     name: "mvjoin(X,Y)",
// //     description: "Join multivalued field",
// //     category: "Eval Functions",
// //   },
// //   {
// //     name: "now()",
// //     description: "Current Unix time",
// //     category: "Eval Functions",
// //   },
// //   { name: "null()", description: "Returns NULL", category: "Eval Functions" },
// //   {
// //     name: "nullif(X,Y)",
// //     description: "Returns X if different from Y",
// //     category: "Eval Functions",
// //   },
// //   {
// //     name: "random()",
// //     description: "Random number generator",
// //     category: "Eval Functions",
// //   },
// //   {
// //     name: "relative_time(X,Y)",
// //     description: "Apply relative time to epoch",
// //     category: "Eval Functions",
// //   },
// //   {
// //     name: "round(X,Y)",
// //     description: "Round number",
// //     category: "Eval Functions",
// //   },
// //   {
// //     name: "split(X,Y)",
// //     description: "Split string into multivalue",
// //     category: "Eval Functions",
// //   },
// //   { name: "sqrt(X)", description: "Square root", category: "Eval Functions" },
// //   {
// //     name: "strftime(X,Y)",
// //     description: "Epoch to formatted string",
// //     category: "Eval Functions",
// //   },
// //   {
// //     name: "strptime(X,Y)",
// //     description: "Parse string to epoch",
// //     category: "Eval Functions",
// //   },
// //   {
// //     name: "substr(X,Y,Z)",
// //     description: "Substring from position",
// //     category: "Eval Functions",
// //   },
// //   {
// //     name: "time()",
// //     description: "Wall clock time",
// //     category: "Eval Functions",
// //   },
// //   {
// //     name: "tonumber(X,Y)",
// //     description: "String to number",
// //     category: "Eval Functions",
// //   },
// //   {
// //     name: "tostring(X,Y)",
// //     description: "Convert to string",
// //     category: "Eval Functions",
// //   },
// //   {
// //     name: "typeof(X)",
// //     description: "Returns field type",
// //     category: "Eval Functions",
// //   },
// //   {
// //     name: "urldecode(X)",
// //     description: "Decode URL",
// //     category: "Eval Functions",
// //   },
// //   {
// //     name: "validate(X,Y,...)",
// //     description: "Validation logic",
// //     category: "Eval Functions",
// //   },

// //   // ================= STATS FUNCTIONS =================
// //   { name: "avg(X)", description: "Average", category: "Stats Functions" },
// //   {
// //     name: "count(X)",
// //     description: "Count events",
// //     category: "Stats Functions",
// //   },
// //   { name: "dc(X)", description: "Distinct count", category: "Stats Functions" },
// //   {
// //     name: "earliest(X)",
// //     description: "Earliest value/time",
// //     category: "Stats Functions",
// //   },
// //   {
// //     name: "latest(X)",
// //     description: "Latest value/time",
// //     category: "Stats Functions",
// //   },
// //   {
// //     name: "median(X)",
// //     description: "Median value",
// //     category: "Stats Functions",
// //   },
// //   { name: "percX(Y)", description: "Percentile", category: "Stats Functions" },
// //   { name: "range(X)", description: "Max - Min", category: "Stats Functions" },
// //   {
// //     name: "stdev / stdevp",
// //     description: "Standard deviation",
// //     category: "Stats Functions",
// //   },
// //   { name: "sum(X)", description: "Sum of values", category: "Stats Functions" },
// //   {
// //     name: "values(X)",
// //     description: "Distinct list",
// //     category: "Stats Functions",
// //   },

// //   // ================= REGEX =================
// //   { name: "\\s", description: "Whitespace", category: "Regex Reference" },
// //   { name: "\\S", description: "Non-whitespace", category: "Regex Reference" },
// //   { name: "\\d", description: "Digit", category: "Regex Reference" },
// //   { name: "\\D", description: "Non-digit", category: "Regex Reference" },
// //   { name: "\\w", description: "Word character", category: "Regex Reference" },
// //   {
// //     name: "\\W",
// //     description: "Non-word character",
// //     category: "Regex Reference",
// //   },
// //   { name: "*", description: "Zero or more", category: "Regex Reference" },
// //   { name: "+", description: "One or more", category: "Regex Reference" },
// //   { name: "?", description: "Optional", category: "Regex Reference" },
// //   { name: "^", description: "Start of line", category: "Regex Reference" },
// //   { name: "$", description: "End of line", category: "Regex Reference" },

// //   // ================= TIME FORMATS =================
// //   { name: "%H", description: "Hour (00–23)", category: "Date & Time Formats" },
// //   { name: "%M", description: "Minute", category: "Date & Time Formats" },
// //   { name: "%S", description: "Seconds", category: "Date & Time Formats" },
// //   { name: "%Y", description: "Year full", category: "Date & Time Formats" },
// //   { name: "%y", description: "Year short", category: "Date & Time Formats" },
// //   { name: "%m", description: "Month", category: "Date & Time Formats" },
// //   { name: "%d", description: "Day of month", category: "Date & Time Formats" },
// //   { name: "%p", description: "AM / PM", category: "Date & Time Formats" },
// //   {
// //     name: "%z",
// //     description: "Timezone offset",
// //     category: "Date & Time Formats",
// //   },
// //   { name: "%Z", description: "Timezone name", category: "Date & Time Formats" },
// //   {
// //     name: "%s",
// //     description: "Seconds since 1970",
// //     category: "Date & Time Formats",
// //   },
// // ];

// // const Commands = () => {
// //   const [search, setSearch] = useState("");
// //   const [darkMode, setDarkMode] = useState(false);
// //   const [userEmail, setUserEmail] = useState("");

// //   useEffect(() => {
// //     const e = localStorage.getItem("user") || "";
// //     setUserEmail(e);
// //   });
// //   const filtered = COMMANDS.filter(
// //     (cmd) =>
// //       cmd.name.toLowerCase().includes(search.toLowerCase()) ||
// //       cmd.description.toLowerCase().includes(search.toLowerCase()) ||
// //       cmd.category.toLowerCase().includes(search.toLowerCase())
// //   );

// //   return (
// //     <div className="min-h-screen bg-white dark:bg-gray-950 text-gray-900 dark:text-gray-100 p-6 mt-1">
// //       {/* HEADER */}
// //       <div className="max-w-7xl mx-auto mb-6">
// //         <div className="bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-2xl p-6 shadow flex items-center justify-between">
// //           {/* LEFT SIDE */}
// //           <div>
// //             <h1 className="text-2xl font-bold text-gray-800 dark:text-white">
// //               To-Analytics Learning Portal
// //             </h1>
// //             <p className="text-sm text-gray-500 dark:text-gray-400">
// //               Professional Splunk Bootcamp Dashboard
// //             </p>
// //           </div>

// //           {/* RIGHT SIDE */}
// //           <div className="flex items-center gap-4">
// //             <div className="text-sm text-gray-600 dark:text-gray-300">
// //               {userEmail}
// //             </div>

// //             <DashboardDropdown />

// //             <button
// //               onClick={() => setDarkMode(!darkMode)}
// //               className="px-3 py-1 rounded-lg text-sm 
// //               bg-gray-100 text-gray-800 
// //               dark:bg-gray-800 dark:text-white
// //               border border-gray-300 dark:border-gray-700
// //               hover:bg-gray-200 dark:hover:bg-gray-700 transition"
// //             >
// //               {darkMode ? "Light Mode" : "Dark Mode"}
// //             </button>
// //           </div>
// //         </div>
// //       </div>

// //       {/* TITLE */}
// //       <h1 className="text-3xl font-bold mb-6 text-gray-800 dark:text-white">
// //         Splunk Command Explorer
// //       </h1>

// //       {/* SEARCH BAR */}
// //       <div className="flex items-center bg-white dark:bg-gray-900 border border-gray-300 dark:border-gray-700 rounded-xl p-3 mb-6 max-w-md shadow">
// //         <Search className="text-gray-500 mr-2" size={18} />
// //         <input
// //           type="text"
// //           placeholder="Search command, regex, function..."
// //           value={search}
// //           onChange={(e) => setSearch(e.target.value)}
// //           className="bg-transparent w-full outline-none text-gray-800 dark:text-white placeholder:text-gray-400"
// //         />
// //       </div>

// //       {/* RESULTS */}
// //       <div className="grid md:grid-cols-2 gap-6">
// //         {filtered.map((cmd, index) => (
// //           <div
// //             key={index}
// //             className="bg-white dark:bg-gray-900 
// //           border border-gray-200 dark:border-gray-700 
// //           p-5 rounded-xl shadow hover:shadow-md transition"
// //           >
// //             <h3 className="text-gray-800 dark:text-white text-lg font-semibold">
// //               {cmd.name}
// //             </h3>

// //             <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
// //               {cmd.description}
// //             </p>

// //             <p className="text-xs text-gray-500 dark:text-gray-500 mt-2">
// //               {cmd.category}
// //             </p>
// //           </div>
// //         ))}
// //       </div>

// //       {/* DOCUMENT SECTION */}
// //       <div className="mt-10">{/* Keep for future document preview */}</div>
// //     </div>
// //   );

// //   // return (
// //   //   <div className="min-h-screen  text-white p-6 mt-20">
// //   //     <div className="max-w-7xl mx-auto mb-6">
// //   //       <div className="bg-white dark:bg-gray-900 rounded-2xl p-6 shadow flex items-center justify-between">
// //   //         {/* LEFT SIDE - TITLE */}
// //   //         <div>
// //   //           <h1 className="text-2xl font-bold text-gray-800 dark:text-white">
// //   //             To-Analytics Learning Portal
// //   //           </h1>
// //   //           <p className="text-sm text-gray-500 dark:text-gray-400">
// //   //             Professional Splunk Bootcamp Dashboard
// //   //           </p>
// //   //         </div>

// //   //         {/* RIGHT SIDE - ACTIONS */}
// //   //         <div className="flex items-center gap-4">
// //   //           {/* User Email */}
// //   //           <div className="text-sm text-gray-600 dark:text-gray-300">
// //   //             {userEmail}
// //   //           </div>

// //   //           {/* Profile Button */}
// //   //           {/* <button
// //   //                  onClick={() => setProfileOpen(true)}
// //   //                  className="px-3 py-1 text-sm rounded bg-blue-600 text-white hover:bg-blue-700 transition"
// //   //                >
// //   //                  My Profile
// //   //                </button> */}

// //   //           <DashboardDropdown />
// //   //           {/* Dark Mode Toggle */}
// //   //           <button
// //   //             onClick={() => setDarkMode(!darkMode)}
// //   //             className="px-3 py-1 rounded text-sm
// //   //            bg-gray-200 text-gray-800
// //   //            dark:bg-gray-800 dark:text-white
// //   //            hover:opacity-90 transition"
// //   //           >
// //   //             {darkMode ? "Light Mode" : "Dark Mode"}
// //   //           </button>
// //   //         </div>
// //   //       </div>
// //   //     </div>

// //   //     <h1 className="text-3xl font-bold mb-4 text-cyan-400 pt-10">
// //   //       Splunk Command Explorer
// //   //     </h1>

// //   //     {/* Search */}
// //   //     <div className="flex items-center bg-[#1e293b] p-3 rounded-xl mb-6 max-w-md">
// //   //       <Search className="text-cyan-400 mr-2" size={18} />
// //   //       <input
// //   //         type="text"
// //   //         placeholder="Search command, regex, function..."
// //   //         value={search}
// //   //         onChange={(e) => setSearch(e.target.value)}
// //   //         className="bg-transparent w-full outline-none text-white placeholder:text-gray-500"
// //   //       />
// //   //     </div>

// //   //     {/* Results */}
// //   //     <div className="grid md:grid-cols-2 gap-4">
// //   //       {filtered.map((cmd, index) => (
// //   //         <div
// //   //           key={index}
// //   //           className="bg-[#1e293b] p-4 rounded-xl border border-slate-700 hover:border-cyan-500 transition"
// //   //         >
// //   //           <h3 className="text-cyan-400 text-lg font-semibold">{cmd.name}</h3>
// //   //           <p className="text-sm text-gray-300 mt-1">{cmd.description}</p>
// //   //           <p className="text-xs text-gray-500 mt-2">{cmd.category}</p>
// //   //         </div>
// //   //       ))}
// //   //     </div>

// //   //     {/* Document preview */}
// //   //     <div className="mt-10">

// //   //     </div>
// //   //   </div>
// //   // );
// // };

// // export default Commands;

// // // import { useState, useEffect } from "react";
// // // import DashboardDropdown from "./Dropdown";

// // // const Commands = () => {
// // //   const [assignment, setAssignment] = useState(null);
// // //   const [selectedDoc, setSelectedDoc] = useState(null);

// // //   useEffect(() => {
// // //     // Example assignment data
// // //     const data = {
// // //       title: "Splunk Commands",
// // //       description:
// // //         "Read all the documents below carefully and complete the required tasks.",
// // //       docs: [
// // //         // {
// // //         //   id: 1,
// // //         //   title: "Assignment Instructions",
// // //         //   url: "https://drive.google.com/file/d/1bf5cRkcEC3yDJ5MnzpRKDpRLhRhdUH90/preview",
// // //         //   dueDate: "2025-11-08",
// // //         // },
// // //         // {
// // //         //   id: 2,
// // //         //   title: "Sample Log Files",
// // //         //   url: "https://drive.google.com/file/d/1swg7fD7Q6DEO_E8PQZTIiPCrNtikWlSK/preview",
// // //         //   dueDate: "2025-11-09",
// // //         // },
// // //         // {
// // //         //   id: 3,
// // //         //   title: "Submission Template",
// // //         //   url: "https://drive.google.com/file/d/1zExampleTemplate123/preview",
// // //         //   dueDate: "2025-11-10",
// // //         // },
// // //           {
// // //            id: 4,
// // //           title: "Splunk Commands ",
// // //           url: "https://drive.google.com/file/d/1jAkmrbTWQApPg7qg43bBfAe4bEg8o0VT/preview",
// // //         //   dueDate: "2025-11-8",

// // //         },
// // //         //   {
// // //         //   id: 5,
// // //         //   title: "Splunk class 3 Assignment",
// // //         //   url: " https://drive.google.com/file/d/179_DKTqGoGjBrszOPRCJqGu3VFlXUbXe/preview",
// // //         //   dueDate: "2025-11-10",
// // //         // },
// // //       ],

// // //     };

// // //     setAssignment(data);
// // //     setSelectedDoc(data.docs[0]);
// // //   }, []);

// // //   if (!assignment) return <p>Loading assignment...</p>;

// // //   return (
// // //     <div className="p-6 space-y-8 bg-gray-50 min-h-screen">
// // //     <DashboardDropdown/>

// // //       <h1 className="text-2xl font-bold text-gray-800">📝 Commands</h1>

// // //       <div className="bg-white shadow-md rounded-2xl p-6">
// // //         <h2 className="text-xl font-semibold text-gray-800 mb-2">
// // //           {assignment.title}
// // //         </h2>
// // //         <p className="text-gray-700 mb-3">{assignment.description}</p>

// // //         {/* === MULTIPLE PDF BUTTONS === */}
// // //         <div className="flex flex-wrap gap-3 mb-4">
// // //           {assignment.docs.map((doc) => (
// // //             <button
// // //               key={doc.id}
// // //               onClick={() => setSelectedDoc(doc)}
// // //               className={`px-4 py-2 rounded-xl text-sm font-medium transition-all duration-200 ${
// // //                 selectedDoc?.id === doc.id
// // //                   ? "bg-blue-600 text-white shadow"
// // //                   : "bg-gray-100 hover:bg-gray-200"
// // //               }`}
// // //             >
// // //               {doc.title}
// // //             </button>
// // //           ))}
// // //         </div>

// // //         {/* === PDF VIEWER === */}
// // //         <div className="w-full h-[600px] rounded-xl overflow-hidden border">
// // //           {selectedDoc && (
// // //             <iframe
// // //               src={selectedDoc.url}
// // //               title={selectedDoc.title}
// // //               className="w-full h-full"
// // //               frameBorder="0"
// // //               allowFullScreen
// // //             ></iframe>
// // //           )}
// // //         </div>

// // //         {/* === DETAILS BELOW VIEWER === */}
// // //         {selectedDoc && (
// // //           <div className="mt-3 text-sm text-gray-600 space-y-1">
// // //             <p>
// // //               <span className="font-semibold">Document:</span>{" "}
// // //               {selectedDoc.title}
// // //             </p>
// // //             <p>
// // //               <span className="font-semibold">Due Date:</span>{" "}
// // //               {selectedDoc.dueDate}
// // //             </p>
// // //             <p>
// // //               <span className="font-semibold">Open in new tab:</span>{" "}
// // //               <a
// // //                 href={selectedDoc.url}
// // //                 target="_blank"
// // //                 rel="noopener noreferrer"
// // //                 className="text-blue-600 underline break-words"
// // //               >
// // //                 {selectedDoc.url}
// // //               </a>
// // //             </p>
// // //           </div>
// // //         )}
// // //       </div>
// // //     </div>
// // //   );
// // // };

// // // export default Commands
